package domain;

public class EntryCard {
	
	int IDNumber;
	int cardNumber;
	int cardFee;
	int assignedUserID;

}
