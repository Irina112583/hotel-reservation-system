package domain;

import java.util.ArrayList;
import java.util.Date;

public class Receptionist extends User{

}
